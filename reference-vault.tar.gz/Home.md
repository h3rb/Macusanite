---
title: Macusanite
color: '#ffd700'
link-color: Coral
tags: [guide, vault]
---
# Welcome to your vault

Macusanite reads a **vault**: a folder tree full of markdown. Folders are
*chambers*, and every `.md` file inside them is a *vein*.

> [!TIP] Everything below is a live document — click a link, then watch the graph
> on the right recolour and the breadcrumbs at the top fill in.

## The three panes

| Pane | What it does |
| --- | --- |
| Left | Vault tree — click a chamber to fold it open, click a vein to read it |
| Centre | The rendered vein, with colour swatches beside pages, links and sections |
| Right | Concept graph of this note and its context in the wider vault |

## Where to go next

* [[Chambers/Fieldwork/Macusanite Occurrence]] — where the glass is found
* [[Chambers/Mineralogy/Cesium Enrichment]] — why this rock matters
* [[Chambers/Lab/Analytical Methods]] — how we measure it
* [[Chambers/Fieldwork/Sampling Plan|the sampling plan]] — aliased links work too
* [[Glossary]] — not written yet, so this one is a ghost you can create

## Diagramming

Mermaid fences are rendered in place:

```mermaid
flowchart LR
  Field[Field sampling] --> Prep[Sample prep]
  Prep --> Analysis[Analysis]
  Analysis --> Model[Petrogenetic model]
  Field --> Log[Field log]
```

### Flowchart

A flowchart lays a process out left to right — the same shape the
progression board on this canvas borrows: earlier steps on the left,
later ones towards the right.

### Sequence diagram

A sequence diagram names the actors and the order they speak in, top to
bottom. Both diagram kinds render in place, exactly where they are written.

## Reference cards and hand-written links

A reference card points at another vein without leaving this one:
![[Chambers/Fieldwork/Sampling Plan]]

Ordinary markdown links work as well — [the sieve series](Chambers/Lab/Analytical%20Methods.md#Sieve%20series),
a hand-written one with spaces in the name, [analytical methods](Chambers/Lab/Analytical Methods.md), and web
links such as [mermaid docs](https://mermaid.js.org/) open in your browser instead of the vault window.

- [x] open a vault
- [ ] colour a section
- [ ] create a vein from a ghost link

## Colour, everywhere

Every page, every link and every section can carry a colour. Click the little
swatch next to a heading or a link and pick one — link colours fade along the
line in the graph towards the colour of their target.

## Try the Worldbuilding canvas

This page opens as a Worldbuilding canvas (the switch at the top right of the
centre pane). Everything new lives here:

* **Overview** folds every card, then fits the whole graph to the screen — a
  bird's-eye table of contents. **Fit**, **Fit selection** and
  **Centre** find far-apart cards without panning.
* Cards snap to guides while dragging; a Ctrl+click selection drags as a unit,
  then **Align** and **Distribute** tidy the set.
* The red group is **locked**: its cards cannot move or be removed, but links
  can still be added. The blue group and the pinned card stay put while
  **Arrange** works around them.
* Connectors run as **elbow** wires with **arrowheads**, and the yellow notes
  are free-floating **annotations**. The health panel (⚠ in the toolbar) lists
  orphans and thin groups.
* The **Progression board** group is split into Kanban-style columns by
  heading tier: the top card on the left, its subsections one tier to the
  right, and their own subsections to the right of those. Right-click a
  group to split it, or use **Arrange → Progression**.
* Canvas undo steps are **named** — use the history browser beside the undo
  button to jump between them, and the file-history log to see the vault's
  whole story.

For the full tour, see [[Chambers/Vault Notes#Worldbuilding canvas tour]].
